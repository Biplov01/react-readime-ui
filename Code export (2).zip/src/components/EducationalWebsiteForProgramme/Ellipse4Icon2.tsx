import { memo, SVGProps } from 'react';

const Ellipse4Icon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 29 29' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={14.6091} cy={14.2186} r={14.0486} stroke='white' strokeOpacity={0.5} strokeWidth={0.439019} />
  </svg>
);

const Memo = memo(Ellipse4Icon2);
export { Memo as Ellipse4Icon2 };
