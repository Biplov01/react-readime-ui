import { memo, SVGProps } from 'react';

const Ellipse2Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 177 177' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={88.4564} cy={88.7538} r={87.8038} fill='url(#paint0_linear_103_39)' />
    <defs>
      <linearGradient
        id='paint0_linear_103_39'
        x1={108.212}
        y1={97.0952}
        x2={-30.9279}
        y2={0.440449}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#E21CCF' />
        <stop offset={1} stopColor='#00B3CC' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse2Icon);
export { Memo as Ellipse2Icon };
