import { memo, SVGProps } from 'react';

const Ellipse3Icon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 154 155' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={76.926} cy={77.2881} r={76.8283} fill='url(#paint0_linear_103_38)' />
    <defs>
      <linearGradient
        id='paint0_linear_103_38'
        x1={101.072}
        y1={32.2886}
        x2={-54.8442}
        y2={97.011}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#E918D4' />
        <stop offset={1} stopColor='#00B3CC' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse3Icon2);
export { Memo as Ellipse3Icon2 };
