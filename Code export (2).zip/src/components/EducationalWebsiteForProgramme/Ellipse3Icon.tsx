import { memo, SVGProps } from 'react';

const Ellipse3Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 154 154' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={76.8283} cy={76.8283} r={76.8283} fill='url(#paint0_linear_103_37)' />
    <defs>
      <linearGradient
        id='paint0_linear_103_37'
        x1={100.974}
        y1={31.8289}
        x2={-54.9419}
        y2={96.5513}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#D6FF7F' />
        <stop offset={1} stopColor='#00B3CC' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse3Icon);
export { Memo as Ellipse3Icon };
