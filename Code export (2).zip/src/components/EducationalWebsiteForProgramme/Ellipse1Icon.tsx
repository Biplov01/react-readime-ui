import { memo, SVGProps } from 'react';

const Ellipse1Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 97 97' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={48.6075} cy={48.3163} r={48.2921} fill='url(#paint0_linear_103_40)' />
    <defs>
      <linearGradient
        id='paint0_linear_103_40'
        x1={33.6809}
        y1={27.2434}
        x2={89.8753}
        y2={110.657}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#D32DEE' />
        <stop offset={1} stopColor='#00B3CC' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse1Icon);
export { Memo as Ellipse1Icon };
