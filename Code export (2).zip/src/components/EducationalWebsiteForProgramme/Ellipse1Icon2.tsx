import { memo, SVGProps } from 'react';

const Ellipse1Icon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 97 97' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={48.2921} cy={48.2921} r={48.2921} fill='url(#paint0_linear_103_433)' />
    <defs>
      <linearGradient
        id='paint0_linear_103_433'
        x1={33.3655}
        y1={27.2192}
        x2={89.5599}
        y2={110.633}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#702E8E' />
        <stop offset={1} stopColor='#00B3CC' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse1Icon2);
export { Memo as Ellipse1Icon2 };
