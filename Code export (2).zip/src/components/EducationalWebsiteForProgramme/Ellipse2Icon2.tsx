import { memo, SVGProps } from 'react';

const Ellipse2Icon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 232 232' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={116} cy={116} r={116} fill='url(#paint0_linear_103_437)' />
    <defs>
      <linearGradient
        id='paint0_linear_103_437'
        x1={142.1}
        y1={127.02}
        x2={-41.7219}
        y2={-0.673157}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#FF7FF2' />
        <stop offset={1} stopColor='#00B3CC' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse2Icon2);
export { Memo as Ellipse2Icon2 };
