import { memo, SVGProps } from 'react';

const Ellipse3Icon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 155 155' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={77.5076} cy={77.6076} r={76.8283} fill='url(#paint0_linear_103_429)' />
    <defs>
      <linearGradient
        id='paint0_linear_103_429'
        x1={59.7273}
        y1={37.2178}
        x2={78.6383}
        y2={185.037}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#D6FF7F' />
        <stop offset={1} stopColor='#00B3CC' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse3Icon3);
export { Memo as Ellipse3Icon3 };
