import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './EducationalWebsiteForProgramme.module.css';
import { Ellipse1Icon2 } from './Ellipse1Icon2.js';
import { Ellipse1Icon } from './Ellipse1Icon.js';
import { Ellipse2Icon2 } from './Ellipse2Icon2.js';
import { Ellipse2Icon } from './Ellipse2Icon.js';
import { Ellipse3Icon2 } from './Ellipse3Icon2.js';
import { Ellipse3Icon3 } from './Ellipse3Icon3.js';
import { Ellipse3Icon } from './Ellipse3Icon.js';
import { Ellipse4Icon2 } from './Ellipse4Icon2.js';
import { Ellipse4Icon3 } from './Ellipse4Icon3.js';
import { Ellipse4Icon } from './Ellipse4Icon.js';
import { Vector1Icon } from './Vector1Icon.js';
import { Vector2Icon } from './Vector2Icon.js';
import { Vector3Icon } from './Vector3Icon.js';
import { WebDevelopmentIcon } from './WebDevelopmentIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 9:5 */
export const EducationalWebsiteForProgramme: FC<Props> = memo(function EducationalWebsiteForProgramme(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.ellipse3}>
        <Ellipse3Icon className={classes.icon} />
      </div>
      <div className={classes.landingPage}>
        <div className={classes.ellipse32}>
          <Ellipse3Icon2 className={classes.icon2} />
        </div>
        <div className={classes.ellipse2}>
          <Ellipse2Icon className={classes.icon3} />
        </div>
        <div className={classes.ellipse1}>
          <Ellipse1Icon className={classes.icon4} />
        </div>
        <div className={classes.cODEME}>CODEME</div>
        <div className={classes.frame1}>
          <div className={classes.home}>Home</div>
          <div className={classes.courses}>Courses</div>
          <div className={classes.contact}>Contact</div>
        </div>
        <div className={classes.frame3}>
          <div className={classes.login}>Login</div>
          <div className={classes.frame2}>
            <div className={classes.signUp}>Sign up</div>
          </div>
        </div>
        <div className={classes.frame4}>
          <div className={classes.learnAProgrammingLanguageIOTAn}>
            <div className={classes.textBlock}>Learn a Programming Language, IOT and robotics</div>
            <div className={classes.textBlock2}>
              <p className={classes.labelWrapper}>
                <span className={classes.label}>The Gateway to Endless Innovation</span>
              </p>
            </div>
          </div>
          <div className={classes.frame22}>
            <div className={classes.getStarted}>Get Started</div>
          </div>
        </div>
        <div className={classes.webDevelopment}>
          <WebDevelopmentIcon className={classes.icon5} />
        </div>
        <div className={classes.ellipse33}>
          <Ellipse3Icon3 className={classes.icon6} />
        </div>
        <div className={classes.frame5}>
          <div className={classes._1JavaScript}>
            <p className={classes.labelWrapper2}>
              <span className={classes.label2}>01/</span>
              <span className={classes.label3}>JavaScript</span>
            </p>
          </div>
          <div className={classes.ellipse4}>
            <Ellipse4Icon className={classes.icon7} />
          </div>
          <div className={classes.aScriptingLanguageUsedToCreate}>
            A scripting language used to create interactive and dynamic websites.
          </div>
          <div className={classes.frame23}>
            <div className={classes.viewCourse}>View Course</div>
          </div>
        </div>
        <div className={classes.frame6}>
          <div className={classes._2Python}>
            <p className={classes.labelWrapper3}>
              <span className={classes.label4}>02/</span>
              <span className={classes.label5}>Python</span>
            </p>
          </div>
          <div className={classes.ellipse42}>
            <Ellipse4Icon2 className={classes.icon8} />
          </div>
          <div className={classes.frame24}>
            <div className={classes.viewCourse2}>View Course</div>
          </div>
          <div className={classes.aHighLevelProgrammingLanguageU}>
            A high-level programming language used for data analysis, artificial intelligence, machine learning, and web
            developmewnt.
          </div>
        </div>
        <div className={classes.frame7}>
          <div className={classes._3PHP}>
            <p className={classes.labelWrapper4}>
              <span className={classes.label6}>03/</span>
              <span className={classes.label7}>PHP</span>
            </p>
          </div>
          <div className={classes.ellipse43}>
            <Ellipse4Icon3 className={classes.icon9} />
          </div>
          <div className={classes.frame25}>
            <div className={classes.viewCourse3}>View Course</div>
          </div>
          <div className={classes.aServerSideScriptingLanguageUs}>
            A server-side scripting language used for creating dynamic web pages and web applications.
          </div>
        </div>
        <div className={classes.pngwing}></div>
        <div className={classes.pngwing1}></div>
        <div className={classes.pngwing2}></div>
        <div className={classes.frame72}>
          <div className={classes.frame26}>
            <div className={classes.viewCourse4}>View Course</div>
          </div>
          <div className={classes.diveIntoTheFieldOfIOT}>Dive into the field of IOT</div>
          <div className={classes.pngwing3}></div>
          <div className={classes._4IOT}>04/IOT</div>
        </div>
      </div>
      <div className={classes.ellipse12}>
        <Ellipse1Icon2 className={classes.icon10} />
      </div>
      <div className={classes.frame2377}>
        <div className={classes.vector3}>
          <Vector3Icon className={classes.icon11} />
        </div>
        <div className={classes.download1}></div>
        <div className={classes.group2}>
          <div className={classes.readime}>Readime</div>
          <div className={classes.educatingTheLearners}>Educating the learners</div>
        </div>
        <div className={classes.vector2}>
          <Vector2Icon className={classes.icon12} />
        </div>
        <div className={classes.vector1}>
          <Vector1Icon className={classes.icon13} />
        </div>
      </div>
      <div className={classes.ellipse22}>
        <Ellipse2Icon2 className={classes.icon14} />
      </div>
    </div>
  );
});
